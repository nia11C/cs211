import java.util.*;
public class lab_2
{
    public static void main (String [] args)
    {
        try {
            SinglyLinkedList<Object> taskList = new SinglyLinkedList<>();

            Task task1 = new Task("T1", 20);
            Task task2 = new Task("T2", 5);
            Task task3 = new Task("T3", 25);
            Task task4 = new Task("T4", 30);
            Task task5 = new Task("T5", 10);
            Task task6 = new Task("T6", 15);

            taskList.addLast(task1);
            taskList.addLast(task2);
            taskList.addLast(task3);
            taskList.addLast(task4);
            taskList.addLast(task5);
            taskList.addLast(task6);

            Print(taskList);
        }
        /*catch(exception E)
        {

        }*/
    }

    /*public static void Print(SinglyLinkedList<Object> taskList)
    {
        System.out.print(taskList);
    }*/

    private static void Print(SinglyLinkedList x)
    {
        System.out.println(x);
    }
}
