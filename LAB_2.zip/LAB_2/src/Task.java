public class Task
{
    private String name;
    private int length;

    public Task (String n, int l)
    {
       name = n;
       length = l;
    }

    public void set_length(int length1)
    {
        length = length1;
    }

    public int get_length()
    {
        return length;
    }

    public void set_name(String name1)
    {
        name = name1;
    }

    public String get_name()
    {
        return name;
    }
}
