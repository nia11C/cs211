public class lab8
{
    public static void main (String [] args)
    {
        ProbeHashMap<Integer,Integer> hashTable1 = new ProbeHashMap<>(5);
        hashTable1.put(1,2);
        hashTable1.put(2,4);
        hashTable1.put(3,6);
        hashTable1.put(4,8);
        hashTable1.put(5,10);
        ProbeHashMap<Integer,Integer> hashTable2 = new ProbeHashMap<>(10);
        hashTable2.put(0,0);
        hashTable2.put(1,2);
        hashTable2.put(2,4);
        hashTable2.put(3,6);
        hashTable2.put(4,8);
        hashTable2.put(5,10);
        hashTable2.put(6,12);
        hashTable2.put(7,14);
        hashTable2.put(8,16);
        hashTable2.put(9,18);
        ProbeHashMap<Integer,Integer> hashTable3 = new ProbeHashMap<>(3);
        hashTable3.put(10,20);
        hashTable3.put(30,40);
        hashTable3.put(50,60);
        hashTable3.put(70,80);
        hashTable3.put(90,100);

        System.out.println("**********");

        System.out.println("Load Factor: " + hashTable1.getLoadFactor());
        System.out.println("Collisions: " + hashTable1.getCollisions());

        System.out.println("**********");

        System.out.println("Load Factor: " + hashTable2.getLoadFactor());
        System.out.println("Collisions: " + hashTable2.getCollisions());

        System.out.println("**********");

        System.out.println("Load Factor: " + hashTable3.getLoadFactor());
        System.out.println("Collisions: " + hashTable3.getCollisions());

        System.out.println("**********");
    }
}
