public class test
{
    public static void main (String [] args) {
        LinkedBinaryTree<String> linked = new LinkedBinaryTree<String>();
        linked.addRoot("A");
        Position<String> A = linked.root();

        linked.addLeft(A, "B");
        Position<String> B = linked.left(A);

        linked.addRight(A, "C");
        Position<String> C = linked.right(A);

        linked.addLeft(B, "E");
        Position<String> E = linked.left(B);

        linked.addRight(B, "F");
        Position<String> F = linked.right(B);

        linked.addLeft(E, "N");
        Position<String> N = linked.left(E);

        linked.addLeft(F, "I");
        Position<String> I = linked.left(F);

        linked.addRight(F, "K");
        Position<String> K = linked.right(F);

        linked.addLeft(C, "G");
        Position<String> G = linked.left(C);

        linked.addRight(C, "H");
        Position<String> H = linked.right(C);

        printChildren(linked, A);
        linked.swapChildren(A);
        System.out.println("----------");
        printChildren(linked, A);
        System.out.println("----------");
        linked.swap(B, C);
        printChildren(linked, A);


    }

    public static void printChildren(LinkedBinaryTree<String> link1, Position<String> p)
    {
        //Node<E> node2 = validate(p);
        if(link1.left(p) != null)
        {
            System.out.println("The child to the left of " + p.getElement() + " is " + link1.left(p).getElement());
        }

        if(link1.right(p) != null)
        {
            System.out.println("The child to the right of " + p.getElement() + " is " + link1.right(p).getElement());
        }
    }


}