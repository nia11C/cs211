import java.util.*;
public class MySinglyLinkedList <E> extends SinglyLinkedList <E>
{
    public void Insert_sorted(Task t)
    {
        Node<E> x = head;
        Node<E> previous = null;

        while(x != null)
        {
            if(t.get_length() < ((Task)x.getElement()).get_length())
            {
                break;
            }
            previous = x;
            x = x.getNext();
        }

        if(size() == 0)
        {
            addFirst((E)t);
        }
        else if(previous == null)
        {
            addFirst((E)t);
        }
        else
        {
            addAfter(previous,(E)t);
        }
    }

    public MySinglyLinkedList()
    {
        super();
    }

    public void print()
    {
        Node<E> x = head;
        int c = 0;
        while(x != null)
        {
            Task t = (Task)x.getElement();

            c += t.get_length();

            System.out.println(t.get_name() + ": finished in " + c + ".");
            x = x.getNext();
        }
    }
}
