public class MyDoublyLinkedList<E> extends DoublyLinkedList<E>
{
    public void Insert_sorted(Task t)
    {
        Node<E> n = header.getNext();
        Node<E> prev = header;
        while(n.getElement() != null)
        {
            if(t.get_length() < ((Task) n.getElement()).get_length())
            {
                break;
            }
            prev = n;
            n = n.getNext();
        }
        addBetween((E) t, prev, n);
    }

    public MyDoublyLinkedList()
    {
        super();
    }

    public void print2()
    {
        Node<E> n = header.getNext();
        int count = 0;
        while(n.getElement() != null)
        {
            Task t = (Task) n.getElement();
            count += t.get_length();
            System.out.println(t.get_name() + ": finished in " + t.get_length() + ". Total time: " + count);
            n = n.getNext();
        }
    }

}
