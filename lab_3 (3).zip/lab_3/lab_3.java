    public class lab_3 {
        public static void main(String[] args) {
            MySinglyLinkedList<Task> taskList = new MySinglyLinkedList<>();
            Task task1 = new Task("T1", 20);
            Task task2 = new Task("T2", 5);
            Task task3 = new Task("T3", 25);
            Task task4 = new Task("T4", 30);
            Task task5 = new Task("T5", 10);
            Task task6 = new Task("T6", 15);
            taskList.Insert_sorted(task1);
            taskList.Insert_sorted(task2);
            taskList.Insert_sorted(task3);
            taskList.Insert_sorted(task4);
            taskList.Insert_sorted(task5);
            taskList.Insert_sorted(task6);
            taskList.print();

            MyDoublyLinkedList<Task> taskList2 = new MyDoublyLinkedList<>();
            Task task7 = new Task("T7", 20);
            Task task8 = new Task("T8", 5);
            Task task9 = new Task("T9", 25);
            Task task10 = new Task("T10", 30);
            Task task11 = new Task("T11", 10);
            Task task12 = new Task("T12", 15);
            Task task13 = new Task("T13", 60);
            taskList2.Insert_sorted(task7);
            taskList2.Insert_sorted(task8);
            taskList2.Insert_sorted(task9);
            taskList2.Insert_sorted(task10);
            taskList2.Insert_sorted(task11);
            taskList2.Insert_sorted(task12);
            taskList2.Insert_sorted(task13);
            System.out.println();
            taskList2.print2();
        }
}
